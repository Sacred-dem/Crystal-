import { useState } from 'react'
import { postChatMessage } from './services/apiClient'
import VoicePanel from './components/VoicePanel'

export default function App() {
  const [message, setMessage] = useState('Hello Crystal')
  const [response, setResponse] = useState('')
  const [busy, setBusy] = useState(false)

  async function send() {
    setBusy(true)
    try {
      const data = await postChatMessage({
        session_id: 'sess_001',
        user_id: 'user_001',
        message,
        mode: 'auto',
        response_format: 'text',
      })
      setResponse(data.assistant_text ?? 'No response')
    } catch (error) {
      setResponse(`Error: ${(error as Error).message}`)
    } finally {
      setBusy(false)
    }
  }

  return (
    <main style={{ padding: 24, fontFamily: 'system-ui', maxWidth: 720 }}>
      <h1>Crystal</h1>
      <p>Hybrid AI companion starter.</p>
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        rows={4}
        style={{ width: '100%', padding: 12, marginBottom: 12, boxSizing: 'border-box' }}
      />
      <button onClick={send} disabled={busy} style={{ padding: '10px 16px' }}>
        {busy ? 'Sending...' : 'Send'}
      </button>
      <section style={{ marginTop: 20 }}>
        <h2>Reply</h2>
        <pre style={{ whiteSpace: 'pre-wrap' }}>{response}</pre>
      </section>
      <VoicePanel />
    </main>
  )
}
