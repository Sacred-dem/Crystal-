import { useRef, useState } from 'react'
import { postChatMessage } from '../services/apiClient'
import { synthesizeVoice, transcribeVoice } from '../services/voiceClient'

export default function VoicePanel() {
  const [recording, setRecording] = useState(false)
  const [status, setStatus] = useState('Idle')
  const [reply, setReply] = useState('')
  const mediaRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<BlobPart[]>([])

  async function startRecording() {
    let stream: MediaStream
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch (error) {
      setStatus(`Microphone unavailable: ${(error as Error).message}`)
      return
    }
    const recorder = new MediaRecorder(stream)
    chunksRef.current = []
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) chunksRef.current.push(event.data)
    }
    recorder.onstop = async () => {
      stream.getTracks().forEach((track) => track.stop())
      try {
        setStatus('Transcribing...')
        const audioBlob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' })
        const transcript = await transcribeVoice(audioBlob)
        if (!transcript.text) {
          setStatus('No speech detected')
          return
        }
        setStatus('Thinking...')
        const chat = await postChatMessage({
          session_id: 'sess_voice',
          user_id: 'voice_user',
          message: transcript.text,
          mode: 'auto',
          response_format: 'text',
        })
        setReply(chat.assistant_text)
        setStatus('Speaking...')
        const ttsBlob = await synthesizeVoice(chat.assistant_text)
        const audioUrl = URL.createObjectURL(ttsBlob)
        const audio = new Audio(audioUrl)
        await audio.play()
        setStatus('Done')
      } catch (error) {
        setStatus(`Voice flow failed: ${(error as Error).message}`)
      }
    }
    recorder.start()
    mediaRef.current = recorder
    setRecording(true)
    setStatus('Recording...')
  }

  function stopRecording() {
    mediaRef.current?.stop()
    mediaRef.current = null
    setRecording(false)
  }

  return (
    <section style={{ border: '1px solid #ccc', padding: 16, borderRadius: 12, marginTop: 16 }}>
      <h2>Voice</h2>
      <p>Status: {status}</p>
      <button onClick={recording ? stopRecording : startRecording}>
        {recording ? 'Stop voice capture' : 'Start voice capture'}
      </button>
      <pre style={{ whiteSpace: 'pre-wrap', marginTop: 16 }}>{reply}</pre>
    </section>
  )
}
