CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  summary TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  format TEXT NOT NULL,
  token_count INTEGER DEFAULT 0,
  metadata_json TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);

CREATE TABLE IF NOT EXISTS memory_items (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  content TEXT NOT NULL,
  embedding_id TEXT,
  confidence REAL DEFAULT 1.0,
  source_message_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public_profiles (
  id TEXT PRIMARY KEY,
  query TEXT NOT NULL,
  display_name TEXT,
  canonical_url TEXT,
  source_count INTEGER DEFAULT 0,
  risk_level TEXT,
  last_analyzed_at TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS profile_scores (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  authenticity INTEGER NOT NULL,
  activity INTEGER NOT NULL,
  influence INTEGER NOT NULL,
  relevance INTEGER NOT NULL,
  risk INTEGER NOT NULL,
  source_quality REAL NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(profile_id) REFERENCES public_profiles(id)
);

CREATE TABLE IF NOT EXISTS evidence_items (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  source_type TEXT NOT NULL,
  url TEXT NOT NULL,
  title TEXT,
  claim TEXT NOT NULL,
  confidence REAL NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY(profile_id) REFERENCES public_profiles(id)
);

CREATE TABLE IF NOT EXISTS artifacts (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  type TEXT NOT NULL,
  title TEXT,
  mime_type TEXT NOT NULL,
  storage_url TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(session_id) REFERENCES sessions(id)
);
