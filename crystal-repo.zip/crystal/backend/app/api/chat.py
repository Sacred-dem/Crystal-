from fastapi import APIRouter
from app.orchestration.orchestrator import Orchestrator
from app.schemas.chat import ChatRequest, ChatResponse

router = APIRouter()
orchestrator = Orchestrator()


@router.post("/message", response_model=ChatResponse)
def message(payload: ChatRequest):
    return orchestrator.respond(payload)
