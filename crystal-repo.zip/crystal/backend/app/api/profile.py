from fastapi import APIRouter
from app.analysis.public_profile import build_public_profile_report
from app.schemas.profile import ProfileAnalyzeRequest, ProfileAnalyzeResponse

router = APIRouter()


@router.post("/analyze", response_model=ProfileAnalyzeResponse)
def analyze(payload: ProfileAnalyzeRequest):
    return build_public_profile_report(
        query=payload.query,
        signals=payload.signals,
        evidence=payload.evidence,
        scoring_profile=payload.scoring_profile,
    )
