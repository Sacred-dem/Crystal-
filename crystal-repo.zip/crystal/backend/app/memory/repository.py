from __future__ import annotations

from app.core.database import get_connection
from app.memory.models import MemoryItem


class MemoryRepository:
    def save(self, item: MemoryItem) -> MemoryItem:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT INTO memory_items (
                    id, user_id, kind, content, embedding_id, confidence,
                    source_message_id, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    item.id,
                    item.user_id,
                    item.kind,
                    item.content,
                    None,
                    item.confidence,
                    item.source_message_id,
                    item.created_at,
                    item.updated_at,
                ),
            )
            conn.commit()
        return item

    def search(self, user_id: str, query: str, limit: int = 5) -> list[dict]:
        with get_connection() as conn:
            cursor = conn.execute(
                """
                SELECT id, user_id, kind, content, confidence, source_message_id, created_at, updated_at
                FROM memory_items
                WHERE user_id = ? AND content LIKE ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (user_id, f"%{query}%", limit),
            )
            rows = cursor.fetchall()
        return [dict(row) for row in rows]

    def recent(self, user_id: str, limit: int = 3) -> list[dict]:
        with get_connection() as conn:
            cursor = conn.execute(
                """
                SELECT id, user_id, kind, content, confidence, source_message_id, created_at, updated_at
                FROM memory_items
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (user_id, limit),
            )
            rows = cursor.fetchall()
        return [dict(row) for row in rows]
